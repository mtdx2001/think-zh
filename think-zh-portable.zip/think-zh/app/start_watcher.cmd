@echo off
rem think-zh watcher launcher (windowless: pythonw + start /b, cmd shell exits instantly)
rem 日志: 本目录 watcher.log；会话源自动探测 DSH_HOME（探测不到时取消下行注释并改为你的 home）
rem set DSH_HOME=C:\Users\you\.dsh
rem 可选多版本会话监听（分号分隔）:
rem set DSH_SESSION_ROOTS=E:\other-dsh-home
chcp 65001 >nul
cd /d %~dp0
start "" /b pythonw -X utf8 -u watcher_service.py >> "%~dp0watcher.log" 2>&1
