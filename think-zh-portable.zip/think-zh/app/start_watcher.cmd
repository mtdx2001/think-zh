@echo off
rem think-zh watcher launcher (windowless, idempotent)
rem Log: watcher.log in this directory.
rem Session source: DSH_HOME is auto-detected. If detection fails, uncomment the
rem line below and point it at your own DSH home directory:
rem set "DSH_HOME=C:\Users\you\.dsh"
rem Optional multi-home session watching (semicolon separated):
rem set "DSH_SESSION_ROOTS=E:\other-dsh-home"
rem NOTE: keep this file ASCII-only. cmd parses the whole file with the ANSI
rem       codepage BEFORE chcp takes effect, so non-ASCII rem lines become
rem       bogus commands. Put any Chinese notes in start_watcher.py instead.
chcp 65001 >nul
cd /d %~dp0
pythonw -X utf8 -u start_watcher.py
exit /b 0
