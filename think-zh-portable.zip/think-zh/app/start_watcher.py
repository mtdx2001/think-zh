#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""think-zh watcher 启动器（便携包通用版）

与仓库版（D:\\think-zh\\app\\start_watcher.py）同源，差异只在：本版**零本机路径**，
可执行文件与 DSH home 全部运行时探测，适配任意解压位置。

为什么需要这个启动器，而不是直接在 .cmd 里启动（四个已实测的缺陷）：
  1. `start /b` 会让 pythonw 继承控制台，父 cmd 等到句柄关闭才退出——
     开机自启场景下表现为「服务已就绪，但 cmd 壳挂着不退出」（实测两次）。
     本启动器由 Python 自己 open() 持有日志句柄后再 Popen，父进程启动即返回。
  2. cmd 的 `>>` 内联重定向在日志文件被占用时会直接报
     「The process cannot access the file because it is being used by another process」。
  3. 幂等判据用 netstat 文本匹配不可靠：同一端口会同时出现 LISTENING 与多条
     TIME_WAIT，且 netstat 行里端口在前、状态在后，findstr 顺序写反即永远漏判
     （本机实测踩中）。本启动器改用 socket 握手实测。
  4. .cmd 里不能写中文注释（cmd 在 chcp 生效前按 ANSI 解析全文，中文 rem 行
     会变成乱码报错命令）——所以中文说明一律放这里。

用法：
    pythonw -X utf8 -u start_watcher.py
或直接双击 start_watcher.cmd。
"""
import glob
import os
import socket
import subprocess
import sys

APP_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(APP_DIR, "watcher.log")
PORT = 18765
SCRIPT = os.path.join(APP_DIR, "watcher_service.py")


def find_pythonw():
    """定位 pythonw.exe：优先 PATH，其次常见安装位置。

    便携包不能写死解释器绝对路径（用户可能装在 C:\\Python313 或 conda 环境），
    故按 PATH → 常见目录 → 当前解释器同目录 的顺序探测。
    """
    import shutil
    found = shutil.which("pythonw")
    if found:
        return found

    # 当前解释器同目录（用户用 python start_watcher.py 启动时会命中这里）
    exe_dir = os.path.dirname(sys.executable)
    for name in ("pythonw.exe", "python.exe"):
        cand = os.path.join(exe_dir, name)
        if os.path.isfile(cand):
            return cand

    # 常见安装位置兜底
    for pat in (
        r"C:\Python3*\pythonw.exe",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Programs\Python\Python3*\pythonw.exe"),
        os.path.join(os.environ.get("USERPROFILE", ""), r"AppData\Local\Programs\Python\Python3*\pythonw.exe"),
    ):
        hits = sorted(glob.glob(pat))
        if hits:
            return hits[-1]
    return None


def port_listening(port, host="127.0.0.1", timeout=1.0):
    """握手实测：真有人监听才返回 True（见文件头第 3 条）。"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        return s.connect_ex((host, port)) == 0


def main():
    if not os.path.isfile(SCRIPT):
        print(f"[start_watcher] 找不到 {SCRIPT}，请确认解压完整")
        return 1

    if port_listening(PORT):
        print(f"[start_watcher] {PORT} 已在监听，跳过重复启动")
        return 0

    exe = find_pythonw()
    if not exe:
        print("[start_watcher] 未找到 pythonw.exe，请确认 Python 已安装并加入 PATH")
        return 1

    env = os.environ.copy()
    # DSH_HOME / DSH_SESSION_ROOTS 若用户已在 .cmd 里 set，此处保持不动；
    # 未设置时交给 watcher_service.py 自行探测（其默认逻辑会兜底 ~/.dsh）。

    logf = open(LOG, "a", encoding="utf-8", errors="replace")
    try:
        subprocess.Popen(
            [exe, "-X", "utf8", "-u", SCRIPT],
            cwd=APP_DIR,
            env=env,
            stdout=logf,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            creationflags=0x08000000 | 0x00000008,  # CREATE_NO_WINDOW | DETACHED_PROCESS
            close_fds=False,
        )
    finally:
        logf.close()   # 子进程已持有自己的副本，父侧可安全关闭

    print(f"[start_watcher] 已拉起 watcher_service.py（端口 {PORT}，解释器 {exe}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
