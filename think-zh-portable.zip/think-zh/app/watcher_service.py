# -*- coding: utf-8 -*-
"""think-zh 实时观察服务（单属主）：
HTTP API(8765) + 会话文件尾随 + 实时翻译(1.8B 常驻) + 观察页。
启动: python watcher_service.py   停止: 结束进程即可（TM 数据落盘安全）
"""
import os, sys, json, time, glob, hashlib, threading, subprocess, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from collections import deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tm_store
from core import protect, split_protected, zh_ratio, build_prompt, clean_output, match_terms

_HERE = os.path.dirname(os.path.abspath(__file__))
try:
    TERMS = json.load(open(os.path.join(_HERE, "terms.json"), encoding="utf-8"))["terms"]
except Exception:
    TERMS = {}

PORT = 18765
# 自包含布局：<根>\app（代码） <根>\llama <根>\models —— 整个根目录可拷走
_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LLAMA_DIR = os.environ.get("TZ_LLAMA", os.path.join(_BASE, "llama"))
MODEL_18B = os.environ.get("TZ_MODEL_18B", os.path.join(_BASE, "models", "Hy-MT2-1.8B-Q6_K.gguf"))
MPORT = 8199

def _newest_session():
    """多根扫描：DSH_HOME 为主根，DSH_SESSION_ROOTS（分号分隔）为扩展根；
    全部候选中选 mtime 最新——本机多 DSH 版本共存时，哪个版本活跃就自动跟哪个。"""
    roots = [os.environ.get("DSH_HOME", os.path.expanduser("~/.dsh"))]
    extra = os.environ.get("DSH_SESSION_ROOTS", "")
    roots += [p.strip() for p in extra.split(";") if p.strip()]
    fs = []
    for root in roots:
        fs += glob.glob(os.path.join(root, "sessions", "**", "session.jsonl.zstd"), recursive=True)
    return max(fs, key=os.path.getmtime) if fs else None

SESSION = os.environ.get("DSH_SESSION_JSONL") or _newest_session()

# ---------------- 占位符规范化 ----------------
import re
_TOK = re.compile(r"\u27e6P(\d{3})\u27e7")

def canonicalize(protected):
    """占位符按首次出现顺序重编号 → 跨块同句式同键。返回 (canonical, mapping{canon_i: orig_i})"""
    seen, order = {}, []
    def _map(m):
        n = int(m.group(1))
        if n not in seen:
            seen[n] = len(seen) + 1
            order.append(n)
        return "\u27e6P%03d\u27e7" % seen[n]
    return _TOK.sub(_map, protected), order

# ---------------- TM 查询（含旧格式规范索引） ----------------
def _sha(s): return hashlib.sha1(s.encode()).hexdigest()[:12]

def tm_init():
    c = tm_store.conn()
    c.execute("CREATE TABLE IF NOT EXISTS canon (ckey TEXT PRIMARY KEY, key TEXT, mapping TEXT)")
    c.commit()

def tm_add_canon(key, protected, commit=True):
    canon, order = canonicalize(protected)
    ckey = _sha(canon)
    c = tm_store.conn()
    c.execute("INSERT OR IGNORE INTO canon(ckey, key, mapping) VALUES (?,?,?)",
              (ckey, key, json.dumps(order)))
    if commit: c.commit()
    return ckey, canon, order

def tm_build_canon_index():
    c = tm_store.conn()
    rows = c.execute("SELECT key, protected FROM tm").fetchall()
    for i, (key, protected) in enumerate(rows):
        tm_add_canon(key, protected, commit=False)
        if i % 2000 == 0: c.commit()
    c.commit()
    return len(rows)

def tm_lookup_by_canonical(ckey):
    c = tm_store.conn()
    return c.execute(
        "SELECT tm.key, tm.translation, tm.source, canon.mapping FROM canon JOIN tm ON tm.key=canon.key "
        "WHERE canon.ckey=?", (ckey,)).fetchone()

def tm_put_canonical(canon, translation, model, source):
    key = _sha(canon)
    tm_store.put(key, canon, translation, model, source)
    c = tm_store.conn()
    c.execute("INSERT OR IGNORE INTO canon(ckey, key, mapping) VALUES (?,?,?)",
              (key, key, json.dumps(list(range(1, 99)))))
    c.commit()
    return key

# ---------------- 常驻 1.8B ----------------
_mproc = [None]
_mproc_start = [0.0]
_model_lock = threading.Lock()

def _adopt_orphans():
    """启动时收养检查：8199 上有响应但非本进程所拉 → 孤儿/旧参数进程。
    health 复用只看存活不看参数，会让参数修改永久失效（跨九天的真实事故）。
    故启动时清掉占 MPORT 的外部 llama-server，确保按当前代码参数重拉。"""
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{MPORT}/health", timeout=1)
    except Exception:
        return   # 端口干净，无需收养
    ps = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "Get-CimInstance Win32_Process -Filter \"Name='llama-server.exe'\" | "
         f"Where-Object {{ $_.CommandLine -match '--port {MPORT}' }} | "
         "Select-Object -ExpandProperty ProcessId"],
        capture_output=True, text=True, timeout=20)
    killed = 0
    for line in ps.stdout.split():
        pid = line.strip()
        if pid.isdigit():
            subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True)
            killed += 1
    if killed:
        print(f"[model] 收养检查：清掉 {killed} 个外部/旧参数 llama-server，稍后按当前参数重拉", flush=True)
        time.sleep(2)

def ensure_model():
    """模型可用性保障：健康即用；端口不通则无条件重生（修复进程死亡后
    _mproc 残留旧对象导致永不重拉的 bug——外部实测塌两小时无人发现）。
    并发安全：模型锁串行化；90 秒宽限期内不杀刚拉起的进程（加载中）。"""
    with _model_lock:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{MPORT}/health", timeout=2) as r:
                if r.status == 200:
                    live["model_up"] = True; return True
        except Exception: pass
        live["model_up"] = False   # 探活失败立即落真实状态，观察页不说谎
        if _mproc[0] is not None:
            try:
                if _mproc[0].poll() is None:
                    if time.time() - _mproc_start[0] < 90:
                        return False   # 刚拉起仍在加载，勿杀勿重拉
                    _mproc[0].kill()
                    print("[model] 模型进程失联，终止并重拉", flush=True)
            except Exception: pass
            _mproc[0] = None
        exe = os.path.join(LLAMA_DIR, "llama-server.exe")
        try:
            _mproc[0] = subprocess.Popen(
                [exe, "-m", MODEL_18B, "-ngl", "99", "-c", "2048", "--port", str(MPORT),
                 "-np", "8", "--threads", "8", "-b", "2048", "-ub", "512", "--no-warmup", "--jinja"],
                cwd=LLAMA_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
                creationflags=0x08000000)   # CREATE_NO_WINDOW：llama 是 console 程序，从 GUI 父进程启动会自建可见终端
            _mproc_start[0] = time.time()
            print("[model] 已按当前参数重拉 llama-server（np=8）", flush=True)
        except Exception as e:
            print(f"[model] 重拉失败: {str(e)[:150]}", flush=True)
            return False
    for _ in range(120):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{MPORT}/health", timeout=2) as r:
                if r.status == 200:
                    live["model_up"] = True; return True
        except Exception: time.sleep(1)
    live["model_up"] = False; return False

def model_guard_loop():
    """周期模型探活（60s）：llama-server 中途死亡自动重生。
    与外部守护任务（进程级）形成双层保险：守护管 watcher 进程，本线程管模型进程。"""
    while True:
        time.sleep(60)
        try:
            if not ensure_model():
                print("[model] 周期探活失败（若连续出现请查显存与模型路径）", flush=True)
        except Exception as e:
            print(f"[model] 探活异常: {str(e)[:150]}", flush=True)   # 不静默：失败必须留痕

def translate_realtime(protected):
    _touch_activity()
    if not ensure_model(): return None
    body = json.dumps({"messages": [{"role": "user", "content": build_prompt(protected, match_terms(protected, TERMS))}],
                       "temperature": 0.7, "top_p": 0.6, "top_k": 20, "repeat_penalty": 1.05,
                       "max_tokens": 1024, "stream": False}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{MPORT}/v1/chat/completions", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            resp = json.loads(r.read())
        return clean_output(resp["choices"][0]["message"]["content"])
    except Exception:
        return None

# ---------------- 句级翻译（查库优先 → 未命中即席） ----------------
def translate_sentences(protected_block, slots, allow_model=True, count=True, keep_skipped=False):
    """块级保护文本 → 切句 → 每句查库/即席 → [{orig, zh, hit}]"""
    out = []
    for s in split_protected(protected_block):
        if zh_ratio(s) > 0.3:
            if keep_skipped:   # 中文占比 ≥30%：原文保留显示（不调模型）——混合句读原文，省 1.8B/7B 算力
                o = _restore_sentence(s, slots)
                out.append({"orig": o, "zh": o, "hit": "orig"})
            continue
        canon, order = canonicalize(s)
        ckey = _sha(canon)
        row = tm_lookup_by_canonical(ckey)
        hit = row is not None and row[1]
        if hit:
            translation, mapping = row[1], json.loads(row[3] or "[]")
            zh = _restore_via_mapping(translation, order, mapping, slots)
            if count:
                live["hits"] += 1
                try: tm_store.bump_hit(ckey)   # 命中落库：hits 不再重启清零
                except Exception: pass         # 计数失败不影响翻译返回
        elif allow_model:
            t = translate_realtime(canon)
            if t is None:
                out.append({"orig": _restore_sentence(s, slots), "zh": None, "hit": None}); continue
            try:
                tm_put_canonical(canon, t, "Hy-MT2-1.8B-Q6_K", "realtime-1.8b")
            except Exception as e:
                print("[tm] 写库失败(不影响返回):", str(e)[:80], flush=True)
            translation, mapping = t, list(range(1, 99))
            zh = _restore_via_mapping(t, order, mapping, slots)
            if count: live["misses"] += 1
        else:
            out.append({"orig": _restore_sentence(s, slots), "zh": None, "hit": None}); continue
        zh = zh.replace("`", "")   # 兼容旧库存译文里混入的反引号
        out.append({"orig": _restore_sentence(s, slots), "zh": zh, "hit": bool(hit)})
    return out

def _restore_sentence(protected, slots):
    return _TOK.sub(lambda m: slots[int(m.group(1)) - 1] if int(m.group(1)) - 1 < len(slots) else m.group(0), protected)

def _restore_via_mapping(translation, query_order, row_mapping, slots):
    """译文占位符(行侧编号) → 查询句槽位值。"""
    inv = {ln: i for i, ln in enumerate(row_mapping, 1)}  # 行编号 -> canon序号
    def _sub(m):
        L = int(m.group(1))
        i = inv.get(L, L)                # 行编号→canon序号（新条目行编号即canon）
        o = query_order[i - 1] if i - 1 < len(query_order) else i  # canon序号→查询原编号
        return slots[o - 1] if o - 1 < len(slots) else m.group(0)
    return _TOK.sub(_sub, translation)

# ---------------- 插件适配层（OpenAI 兼容，供 dsh-think-translate 调用） ----------------
_PAYLOAD_HEAD = re.compile(r"^Target language:\s*\S+\s*\n+", re.I)

def _extract_user_text(messages):
    user = ""
    for m in messages or []:
        if isinstance(m, dict) and m.get("role") == "user":
            user = m.get("content") or ""
    return _PAYLOAD_HEAD.sub("", user).strip()

def openai_translate(body):
    """剥插件包装 → TM 查库优先 → 1.8B 即席（术语表生效）→ 拼 OpenAI 响应。"""
    _touch_activity()
    text = _extract_user_text((body or {}).get("messages"))
    content = ""
    if text:
        if zh_ratio(text) >= 0.25:
            content = text   # 中文块原样直通：不进英→中管线，不产生乱翻条目
        else:
            protected, slots = protect(text)
            sents = translate_sentences(protected, slots, allow_model=True, keep_skipped=True)
            content = "\n".join((s["zh"] or s["orig"]) for s in sents)
    return {"id": "think-zh", "object": "chat.completion", "model": "think-zh",
            "choices": [{"index": 0, "finish_reason": "stop",
                         "message": {"role": "assistant", "content": content}}]}

# ---------------- 会话尾随 ----------------
class TailDecoder:
    """多帧 zstd 增量解码：帧完整即产出，半帧保状态，失步自动重同步。"""
    MAGIC = b"\x28\xb5\x2f\xfd"
    def __init__(self):
        self.d = zstd.ZstdDecompressor().decompressobj()
        self.buf = b""
        self.last_resync_log = 0.0   # 时间节流（连续计数会被逐帧成功清零，节流失效的教训）
    def feed(self, data):
        self.buf += data
        out = []
        while self.buf:
            try:
                piece = self.d.decompress(self.buf)
                rest = self.d.unused_data
            except Exception:
                i = self.buf.find(self.MAGIC, 1)
                if i < 0:
                    self.buf = self.buf[-3:]   # 魔数可能跨读边界，留尾3字节
                    break
                if time.time() - self.last_resync_log > 30:
                    print("[decoder] 帧失步重同步（30s 节流，持续属正常追新）", flush=True)
                    self.last_resync_log = time.time()
                self.buf = self.buf[i:]
                self.d = zstd.ZstdDecompressor().decompressobj()
                continue
            out.append(piece)
            if rest:
                self.buf = rest
                self.d = zstd.ZstdDecompressor().decompressobj()
            else:
                self.buf = b""
                break
        return b"".join(out)

import zstandard as zstd

def _tail_one(path, stop_event=None):
    """尾随单个会话文件：只处理新增内容，不刷屏。

    2026-10-11 新增（多会话并行）：原实现是「单文件尾随 + 每 20 秒重探测最新」，
    而 `_newest_session()` 用 max 单选——两个会话同时活跃时会反复横跳，
    谁在探测瞬间更新就切给谁，**另一个会话的内容整段丢失**。
    实测场景：两个 DSH 会话同时活跃（ddfc4c7b 与 afe1e990 交替更新），
    两边都翻不全，用户看到的就是「另一个会话翻译还是有问题」。
    正解：每个活跃会话各起一个尾随线程，互不干扰。
    """
    dec = TailDecoder()
    try:
        f = open(path, "rb")
    except Exception as e:
        print(f"[watcher] 打开失败 {os.path.basename(os.path.dirname(path))}: {e}", flush=True)
        return
    # 从文件尾部起（历史内容不回放，避免每次启动刷屏且旧块会被 allow_model=False 丢弃）
    off = f.seek(0, 2)
    caught_up = True
    tag = os.path.basename(os.path.dirname(path))[:24]
    print(f"[watcher] tailing {tag} (from tail)", flush=True)
    idle_rounds = 0
    try:
        while True:
            if stop_event is not None and stop_event.is_set():
                break
            f.seek(off)
            data = f.read()
            if data:
                idle_rounds = 0
                off += len(data)
                text = dec.feed(data).decode("utf-8", errors="replace")
                for line in text.split("\n")[:-1]:   # 只处理完整行
                    handle_line(line, allow_model=caught_up)
            else:
                idle_rounds += 1
                # 长时间无新增即退出（由监督线程按需重开），防线程泄漏。
                # 15 分钟无写入 ≈ 该会话已结束；重开时从新尾部继续，代价只是一次 seek。
                if idle_rounds > 2250:   # 2250 * 0.4s = 900s
                    print(f"[watcher] {tag} 空闲超时，释放尾随线程", flush=True)
                    break
            time.sleep(0.4)
    except Exception as e:
        print(f"[watcher] {tag} 尾随异常: {str(e)[:100]}", flush=True)
    finally:
        try: f.close()
        except Exception: pass


def _active_sessions(within_seconds=1800):
    """所有会话根下「最近活跃」的会话文件（默认 30 分钟内有写入）。

    多会话并行监听用。限制窗口是必要的：三个根合计可能有数百个历史会话，
    全部开线程既浪费也无意义。30 分钟覆盖一次正常对话的间歇。
    """
    roots = [os.environ.get("DSH_HOME", os.path.expanduser("~/.dsh"))]
    extra = os.environ.get("DSH_SESSION_ROOTS", "")
    roots += [p.strip() for p in extra.split(";") if p.strip()]
    now = time.time()
    out = []
    for root in roots:
        try:
            for p in glob.glob(os.path.join(root, "sessions", "**", "session.jsonl.zstd"), recursive=True):
                try:
                    if now - os.path.getmtime(p) <= within_seconds:
                        out.append(p)
                except OSError:
                    continue
        except Exception:
            continue
    return out


def watcher_loop():
    """监督线程：为每个活跃会话维持一个尾随线程（2026-10-11 多会话并行）。"""
    explicit = os.environ.get("DSH_SESSION_JSONL")
    if explicit:
        # 显式指定 = 调试/演示用法：只跟这一个，不自动扩展
        live["tail_ready"] = True
        _tail_one(explicit)
        return

    started = {}   # path -> (thread, stop_event)
    while True:
        try:
            active = _active_sessions()
            if active:
                live["tail_ready"] = True

            # 回收已结束的线程
            for p in list(started.keys()):
                th, ev = started[p]
                if not th.is_alive():
                    ev.set()
                    del started[p]

            # 为新出现的活跃会话起尾随线程
            for p in active:
                if p in started and started[p][0].is_alive():
                    continue
                ev = threading.Event()
                th = threading.Thread(target=_tail_one, args=(p, ev), daemon=True)
                th.start()
                started[p] = (th, ev)

            # 观察页显示：取当前正在尾随的会话（多个时任取其一，仅作展示）
            with live["lock"]:
                if started:
                    live["session"] = max(started.keys(), key=os.path.getmtime)

            if len(started) > 1:
                print(f"[watcher] 并行尾随 {len(started)} 个活跃会话", flush=True)

            time.sleep(20)
        except Exception as e:
            print("[watcher] err:", str(e)[:100], flush=True); time.sleep(2)

def handle_line(line, allow_model=True):
    # 2026-10-11 修复（思考流「看不见」的根因）：
    # 上游 DSH 把思考流事件由 `reasoning-chunks` 更名为 `text-chunks`（字段结构不变：
    # data.turn/step/index/dt/texts 完全一致）。旧代码有两道拦截会把它整个漏掉：
    #   1) 本行的前置过滤只放行含 "reasoning" 字样的行——`text-chunks` 不含该字样，被直接丢弃；
    #   2) 下面的类型判断只认 "reasoning-chunks"。
    # 后果：观察器看不到思考内容，只剩旧格式的空事件，表现为「翻译不出来 / 严重滞后」。
    if "reasoning" not in line and "text-chunks" not in line: return
    try: o = json.loads(line)
    except: return
    t = o.get("type")
    # 兼容两种事件名：text-chunks（新） / reasoning-chunks（旧）
    if t in ("reasoning-chunks", "text-chunks"):
        d = o.get("data", {})
        block = "".join(d.get("texts", []))
        if block.strip(): publish_block(block, d.get("turn"), allow_model)
        return
    if t != "assistant/chunk": return
    d2 = o.get("data", {})
    c = d2.get("chunk", {}) or {}
    ct = c.get("type")
    if ct == "reasoning-delta":
        key = (d2.get("turn"), d2.get("step"), c.get("index"))
        b = buffers.setdefault(key, {"text": "", "ts": time.time()})
        b["text"] += (c.get("text") or c.get("delta") or "")
        b["ts"] = time.time()
    elif ct == "block-end":
        # 2026-10-11 修复（滞后根因）：原判据为 c.get("blockType") == "reasoning"，
        # 但上游 DSH 的 block-end 事件 blockType 字段已是 None（实测：当前与历史
        # 全部会话共 384+335+… 个 block-end，blockType 无一为 "reasoning"），
        # 该条件永不成立 ⇒ reasoning-delta 累积的块从不被 flush，
        # 只能等 idle_flusher 的 4 秒无更新兜底 ⇒ 表现为「整段出来后才翻译」。
        #
        # 正解：不依赖 blockType，改用「该 key 是否有累积内容」判定——
        # 有累积说明前面确实来过 reasoning-delta，这就是 reasoning 块的结束。
        # 同时兼容 blockType 仍为 "reasoning" 的旧格式。
        key = (d2.get("turn"), d2.get("step"), c.get("index"))
        if c.get("blockType") == "reasoning" or key in buffers:
            flush_key(key, allow_model)

def flush_key(key, allow_model=True):
    b = buffers.pop(key, None)
    if b and b["text"].strip():
        publish_block(b["text"], key[0], allow_model)

def idle_flusher():
    while True:
        time.sleep(2)
        now = time.time()
        for key in [k for k, b in buffers.items() if now - b["ts"] > 4]:
            flush_key(key, True)

def _passthrough(block, turn):
    """中文块/纯符号块原样入展示流（zh=orig，不调模型、不入库、不产生垃圾条目）。"""
    with live["lock"]:
        live["seq"] += 1
        live["blocks_seen"] += 1
        live["blocks"].append({"seq": live["seq"], "ts": time.strftime("%H:%M:%S"),
                               "turn": turn, "sentences": [{"orig": block, "zh": block, "hit": True}]})

def publish_block(block, turn, allow_model=True):
    # 闸 1：目标语已是中文的块（如中文思考的智能体）不进英→中管线，
    # 原样入展示流——防乱翻入库污染（中文句式不属于本库语域，永远 miss 且译必乱）。
    if zh_ratio(block) >= 0.25:
        _passthrough(block, turn); return
    protected, slots = protect(block)
    # 闸 2：剥掉占位符后几乎无实质英文词的纯符号块（代码行/路径/列表项），
    # 送模型只会原样返回或误译（commit→提交），白耗算力还入库占位——原样入流。
    rest = _TOK.sub("", protected)
    if len(re.findall(r"[A-Za-z]{4,}", rest)) <= 1 and len(rest.strip()) < 40:
        _passthrough(block, turn); return
    sents = translate_sentences(protected, slots, allow_model=allow_model, keep_skipped=True)
    if not sents: return
    if not allow_model and not any(s["hit"] is True for s in sents):
        return  # 回放段：无库命中（守卫跳过句 hit="orig" 不算命中）的块不入展示流
    with live["lock"]:
        live["seq"] += 1
        live["blocks_seen"] += 1
        live["blocks"].append({"seq": live["seq"], "ts": time.strftime("%H:%M:%S"),
                               "turn": turn, "sentences": sents})

# ---------------- HTTP 服务 ----------------
VIEWER = """<!doctype html><html><head><meta charset="utf-8"><title>think-zh 思维链中译</title>
<style>
body{background:#111418;color:#cfd8dc;font-family:Consolas,'Microsoft YaHei',monospace;margin:0;padding:12px}
h1{font-size:15px;color:#80cbc4;margin:0 0 4px}
#stat{font-size:12px;color:#78909c;margin-bottom:10px}
.blk{border-left:3px solid #37474f;padding:4px 10px;margin:8px 0}
.blk:hover{border-color:#80cbc4}
.meta{font-size:11px;color:#546e7a}
.zh{color:#a5d6a7;margin:2px 0}
.en{color:#607d8b;font-size:12px;white-space:pre-wrap;word-break:break-all}
.badge{font-size:10px;border:1px solid #455a64;border-radius:3px;padding:0 4px;margin-left:6px}
.b-hit{color:#81c784}.b-miss{color:#ffb74d}
#mode{background:#00695c;color:#fff;border:1px solid #80cbc4;border-radius:4px;font-size:13px;padding:4px 14px;cursor:pointer;margin-left:14px}
body.zh-only .en{display:none}
</style></head><body>
<h1>think-zh 思维链中译 · 实时观察<button id="mode">纯中文模式</button></h1>
<div id="stat">加载中…</div><div id="feed"></div>
<script>
let after=0, stick=true;
window.onscroll=()=>{stick = (innerHeight+scrollY >= document.body.offsetHeight-40)};
async function tick(){
  const s=await (await fetch('/api/stats')).json();
  document.getElementById('stat').textContent =
    `库 ${s.tm_total} 条 | 本会话块 ${s.blocks_seen} | 命中 ${s.hits} / 未命中 ${s.misses}` +
    ` (命中率 ${s.hits+s.misses?Math.round(100*s.hits/(s.hits+s.misses)):0}%) | 模型 ${s.model_up?'常驻●':'未启○'} | 会话 ${s.session_file}`;
  const r=await (await fetch('/api/recent?after='+after)).json();
  for(const b of r.blocks){
    const div=document.createElement('div');div.className='blk';
    let h=`<div class="meta">#${b.seq} ${b.ts} turn${b.turn??''}</div>`;
    for(const x of b.sentences){
      const badge = x.hit===true?'库':(x.hit===false?'模型':(x.hit==='orig'?'原文':'跳过'));
      const bcls = x.hit===true?'b-hit':(x.hit===false?'b-miss':'b-orig');
      h+=`<div class="zh">${x.zh??'(…模型未就绪)'}</div>`;
      if(x.zh!==null) h+=`<div class="en">${esc(x.orig)}<span class="badge ${bcls}">${badge}</span></div>`;
    }
    div.innerHTML=h;document.getElementById('feed').appendChild(div);
    after=b.seq;
  }
  if(stick) scrollTo(0,document.body.scrollHeight);
}
const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;');
const btn=document.getElementById('mode');
if(localStorage.tzZhOnly!=='0'){document.body.classList.add('zh-only');btn.textContent='对照模式';}
btn.onclick=()=>{const on=document.body.classList.toggle('zh-only');
  btn.textContent=on?'对照模式':'纯中文模式';
  localStorage.tzZhOnly=on?'1':'0';};
setInterval(tick,1500);tick();
</script></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/":
            return self._send(200, VIEWER.encode(), "text/html; charset=utf-8")
        if p == "/api/stats":
            with live["lock"]:
                return self._send(200, {"tm_total": tm_store.stats()["total"],
                    "blocks_seen": live["blocks_seen"], "hits": live["hits"],
                    "misses": live["misses"], "model_up": live["model_up"],
                    "session_file": os.path.basename(live["session"] or ""),
                    "upgrade_pending": pending_upgrade_count(),
                    "corr_running": CORR["running"],
                    "corr_last_done": CORR["last_done"]})
        if p == "/api/recent":
            after = int(self.path.split("after=")[-1].split("&")[0] or 0)
            with live["lock"]:
                blocks = [b for b in live["blocks"] if b["seq"] > after]
            return self._send(200, {"blocks": blocks})
        if p == "/api/lookup":
            from urllib.parse import urlparse, parse_qs, unquote
            q = parse_qs(urlparse(self.path).query)
            text = unquote(q.get("text", [""])[0])
            return self._send(200, {"results": translate_sentences(text, [], allow_model=False)})
        return self._send(404, {"error": "not found"})
    def do_POST(self):
        try:
            p = self.path.split("?")[0]
            if p == "/v1/chat/completions":   # dsh-think-translate 适配入口
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(n) or b"{}")
                return self._send(200, openai_translate(body))
            if p == "/api/translate":
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
                text = req.get("text", "")
                protected, slots = protect(text)
                return self._send(200, {"results": translate_sentences(protected, slots, allow_model=req.get("model", True), keep_skipped=True)})
            return self._send(404, {"error": "not found"})
        except Exception as e:
            return self._send(500, {"error": str(e)[:200]})
    def log_message(self, *a): pass

# ---------------- 空闲自动校正（事后 7B 升级循环） ----------------
CORR = {"last_activity": time.time(), "running": False, "last_done": None, "last_count": 0}
UPGRADE_IDLE_SECS = 600   # 连续 10 分钟无翻译活动才触发
UPGRADE_BATCH = 200       # 单轮条数上限，跑完即卸 7B

def _touch_activity():
    """任何真实翻译活动打点（用户在用 = 不校正）。"""
    CORR["last_activity"] = time.time()

def mining_enabled():
    """挖矿开关：out/mining.off 文件存在 = 停（动态生效，无需重启）。"""
    return not os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "mining.off"))

def pending_upgrade_count():
    try:
        con = tm_store.conn()
        rt = con.execute(
            "SELECT COUNT(*) FROM tm WHERE source LIKE 'realtime-1.8b%' OR needs_review=1"
        ).fetchone()[0]
        off = con.execute(
            "SELECT COUNT(*) FROM tm WHERE source LIKE 'offline-1.8b%'"
        ).fetchone()[0]
        return {"realtime": rt, "offline_stock": off}
    except Exception:
        return {"realtime": 0, "offline_stock": 0}

def idle_upgrade_loop():
    import backfill
    cfg = dict(backfill.PRESETS["7b"]); cfg.update(np=1, ctx=2048)   # 校正专用：串行+小上下文省显存
    idle_since = None   # 空闲起点；挖矿模式下保持已满足状态，连续分批消化存量
    while True:
        time.sleep(20)
        try:
            if CORR["running"]: continue
            if not mining_enabled(): continue
            active = time.time() - CORR["last_activity"] < 30
            if active:
                idle_since = None            # 用户回来了，重新计时
                continue
            if idle_since is None:
                idle_since = time.time()     # 首次检测到空闲
                continue
            if time.time() - idle_since < UPGRADE_IDLE_SECS:
                continue                     # 空闲未满 10 分钟
            # realtime 新句优先；清完则啃 offline-1.8b 铺量存量
            items = tm_store.upgrade_keys("realtime-1.8b") or tm_store.upgrade_keys("offline-1.8b")
            if not items: continue
            batch = items[:UPGRADE_BATCH]
            CORR["running"] = True
            print(f"[校正] 空闲触发: 库中待升级 {len(items)} 条, 本轮 {len(batch)} 条", flush=True)
            try:
                proc = backfill.start_server(cfg)
            except Exception as e:
                print("[校正] 7B 启动失败(显存不足?), 推迟到下个空闲窗口:", str(e)[:120], flush=True)
                continue
            done, t0 = 0, time.time()
            try:
                for key, protected in batch:
                    if time.time() - CORR["last_activity"] < 30:   # 用户回来了，提前收尾
                        print("[校正] 检测到活动, 本轮提前结束", flush=True)
                        break
                    try:
                        trans = backfill.translate_one(cfg["port"], protected)
                        tm_store.update_translation(key, trans, cfg["tag"], "offline-upgrade-7b")
                        done += 1
                    except Exception as e:
                        print(f"[校正] 单条失败 {str(key)[:10]}: {str(e)[:80]}", flush=True)
            finally:
                try: proc.kill()
                except Exception: pass
            CORR["last_done"] = time.time(); CORR["last_count"] = done
            rate = done / max(time.time() - t0, 0.01)
            print(f"[校正] 本轮完成 {done}/{len(batch)} 条  {rate:.1f} 句/s  7B 已卸载", flush=True)
        except Exception as e:
            print("[校正] 循环异常:", str(e)[:120], flush=True)
        finally:
            CORR["running"] = False
            # 挖矿模式：保持"已空闲"状态，20 秒后下一轮连续挖；用户活动会重置 idle_since
            idle_since = time.time() - UPGRADE_IDLE_SECS

# ---------------- 启动 ----------------
buffers = {}
live = {"seq": 0, "blocks": deque(maxlen=200), "lock": threading.Lock(),
        "hits": 0, "misses": 0, "blocks_seen": 0, "model_up": False,
        "session": SESSION, "tail_ready": False}

if __name__ == "__main__":
    tm_init()
    n = tm_build_canon_index()
    print(f"[tm] 规范索引构建: {n} 条")
    threading.Thread(target=watcher_loop, daemon=True).start()
    threading.Thread(target=idle_flusher, daemon=True).start()
    threading.Thread(target=ensure_model, daemon=True).start()
    threading.Thread(target=idle_upgrade_loop, daemon=True).start()
    threading.Thread(target=model_guard_loop, daemon=True).start()
    _adopt_orphans()   # 启动先清外部/旧参数模型进程，保证参数一致（孤儿事故根治）
    print(f"[http] http://127.0.0.1:{PORT}  (观察页 / · API /api/lookup /api/translate /api/stats)")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
